/**
 * Function viewNewCase
 * Description: load the form with parameters
 * (server,workspace,accesToken,refreshToken, procId, taskID, formsArrayJSON, formId, jsonForm)
 */
var app = {},
    viewNewCase,
    viewCase;

window.dynaform = app;
app.openCase = function (server, workspace, accessToken, refreshToken, processId, taskId, caseId, formsArray, delIndex, lang, isRTL) {
    var environment,
        activeCase;
    isRTL = isRTL || false;
    if (navigator.userAgent === "formslider-android")
        environment = "android";
    if (navigator.userAgent === "formslider-ios")
        environment = "ios";

    activeCase = new xCase.core.CaseManager({
        steps: formsArray,
        environment: environment,
        tokens: {
            accessToken: accessToken,
            refreshToken: refreshToken
        },
        config: {
            server: server,
            workspace: workspace,
            taskUID: taskId,
            processUID: processId,
            delIndex: delIndex,
            lang: lang,
            caseUID: caseId
        },
        isRTL: isRTL
    });
    app.activeCase = activeCase;
    activeCase.startCase();
};

app.openStep = function (server, workspace, accessToken, refreshToken, processId, taskId, caseId, formsArray, delIndex, lang, stepInfo, isRTL) {
    var environment,
        respDevice,
        dataServer,
        step,
        activeCase,
        serverDate,
        localDate;
    isRTL = isRTL || false;
    if (navigator.userAgent === "formslider-android")
        environment = "android";
    if (navigator.userAgent === "formslider-ios")
        environment = "ios";

    activeCase = new xCase.core.CaseManager({
        steps: formsArray,
        environment: environment,
        tokens: {
            accessToken: accessToken,
            refreshToken: refreshToken
        },
        config: {
            server: server,
            workspace: workspace,
            taskUID: taskId,
            processUID: processId,
            delIndex: delIndex,
            lang: lang,
            caseUID: caseId
        },
        isRTL: isRTL
    });
    app.activeCase = activeCase;
    respDevice = activeCase.getRequestManager().getStep(stepInfo);
    activeCase.setStepHistory(respDevice["stepHistory"]);
    step = activeCase.stepCollection.findByStepUID(respDevice["stepId"]);

    if (step.existTriggerBefore()) {
        after = activeCase.triggerBefore(respDevice["stepId"]);
    }

    dataServer = activeCase.getData({
        dyn_uid: respDevice.formId || null
    });

    serverDate = moment(dataServer.SYS_VAR_UPDATE_DATE, "YYYY-MM-DD HH:mm:ss");
    localDate = moment(respDevice.updateDate, "YYYY-MM-DD HH:mm:ss");

    if (!serverDate.isValid() || !localDate.isValid()) {
        //default case: open the step with data from device
        activeCase.openStep(respDevice);
    } else if (serverDate.isAfter(localDate)) {
        app.getWhichDataToUse = function (val) {
            if (val === '1') {
                respDevice.data = dataServer;
            } else {
                respDevice.data.SYS_VAR_UPDATE_DATE = respDevice.updateDate;
            }
            activeCase.openStep(respDevice);
        };
        this.activeCase.getRequestManager().askWhichDataToUse();
    } else {
        respDevice.data.SYS_VAR_UPDATE_DATE = respDevice.updateDate;
        activeCase.openStep(respDevice);
    }
};

app.getWhichDataToUse = function () {
};

var kitKatMode = null;
var setKitKatMode = function (value) {
    kitKatMode = value;
};

app.setKitKatMode = setKitKatMode;

app.setFiles = function (input) {
    var parseInput, field, index, name, readStr, resp;
    if (_.isString(input) && input !== "") {
        try {
            parseInput = JSON.parse(input);
            field = getFieldById(parseInput.idField);
            for (index = 0; index < parseInput.files.length; index += 1) {
                if (parseInput.files[index].filePath) {
                    readStr = this.activeCase.getRequestManager().readerFile(parseInput.files[index].filePath, "text");
                    if (readStr) {
                        parseInput.files[index].filePath = readStr;
                    } else {
                        break;
                    }
                }
            }
            if (field) {
                if (_.isFunction(field.setFiles)) {
                    field.setFiles(parseInput.files);
                }
            } else {
                resp = this.activeCase.getRequestManager().executeCallbackAction({
                    id: parseInput.idField,
                    data: parseInput
                });
            }
        }
        catch (e) {
            console.error(e);
        }
    }
};

app.setLocation = function (input) {
    var parseInput,
        field;
    if (_.isString(input) && input !== "") {
        try {
            parseInput = JSON.parse(input);
            field = getFieldById(parseInput.idField);
            if (_.isFunction(field.setLocation)) {
                field.setLocation(parseInput);
            }
        }
        catch (e) {
            console.error(e);
        }
    }
};

app.setScannerCode = function (input) {
    var parseInput,
        field,
        index,
        readStr;

    if (_.isString(input) && input !== "") {
        try {
            parseInput = JSON.parse(input);
            field = getFieldById(parseInput.idField);
            if (_.isFunction(field.setScannerCode)) {
                readStr = this.activeCase.getRequestManager().readerFile(parseInput.data, "text");
                field.setScannerCode({data: readStr});
            }
        }
        catch (e) {
            console.error(e);
        }
    }
};

app.changeID = function (input) {
    var parseInput,
        field;
    if (_.isString(input) && input !== "") {
        try {
            parseInput = JSON.parse(input);
            field = getFieldById(parseInput.idField);
            if (_.isFunction(field.setLocation)) {
                field.changeID(parseInput.data);
            }
        }
        catch (e) {
            console.error(e);
        }
    }
};

/**
 * Interface with device that hide mask loading from a some Field
 * @param input
 */
app.hideFieldLoading = function (input) {
    var parseInput,
        resp,
        field;
    if (_.isString(input) && input !== "") {
        try {
            parseInput = JSON.parse(input);
            field = getFieldById(parseInput.idField);

            resp = this.activeCase.getRequestManager().executeCallbackAction({
                id: parseInput.idFile,
                data: parseInput
            });

            if (resp === false && field) {
                if (_.isFunction(field.hideLoading)) {
                    field.hideLoading();
                }
            }
        }
        catch (e) {
            console.error(e);
        }
    }
};

app.hideMaskLoading = function () {
    this.activeCase.hideMaskLoading();
    return this;
};

app.showMaskLoading = function () {
    this.activeCase.showMaskLoading();
    return this;
};

app.getDataIOS = function () {
    var respData = this.activeCase.getRequestManager().getDataMemory();
    return JSON.stringify(respData);
};

app.validateForms = function () {
    return this.activeCase.getRequestManager().getValidateForm();
};

app.getDataFile = function () {
    var respData = this.activeCase.getRequestManager().getDataMemory();
    return JSON.stringify(respData);
};

app.loadForm = function (formID, path) {
    var json = this.activeCase.getRequestManager().readerFile(path, "json");
    this.activeCase.loadForm(json);
};

app.setCacheLibraryMap = function (path) {
    var json = this.activeCase.getRequestManager().readerFile(path, "json");
    this.activeCase.setCacheLibraryMap(json);
};

app.getFormData = function () {
    var data = this.activeCase.getCurrentStepData();
    this.activeCase.getRequestManager().sendFormData(data);

    if (this.activeCase.environment === "ios") {
        return JSON.stringify(data);
    } else {
        return;
    }
};

var PMURI = {
    encode: function (input) {

    },
    decode: function (input) {
        input = JSON.parse(input, function (key, value) {
            if (typeof value === "string") {
                value = value.replace(/(&d\|t&)/g, "\n");
                value = value.replace(/(&c\|t&)/g, "'");
                value = value.replace(/(&t\|t&)/g, "\t");
            }
            return value;
        });
        return input;
    }
};
